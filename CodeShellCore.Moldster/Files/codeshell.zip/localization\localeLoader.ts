﻿export abstract class LocaleLoader {
    public abstract Load(): any;
}