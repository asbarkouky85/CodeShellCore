﻿export class ViewParams {
    ModelType?: string;
    AddUrl?: string;
    EditUrl?: string;
    DetailsUrl?: string;
    ListUrl?: string;
    Layout?: string;
    Other: { [index: string]: any } = {};
}