﻿import { ListItem } from "./listItem";

export class EditablePairsDTO extends ListItem {
    data: any = {};
}