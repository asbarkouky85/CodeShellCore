import { ListItem } from '../data';

export class EditablePairsDTO extends ListItem {
    data: any = {};
}